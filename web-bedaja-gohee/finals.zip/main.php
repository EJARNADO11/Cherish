<!DOCTYPE html>
<html>
<head>
     <title>Wrap a Meal</title>
</head>
<body>
    <div class="main"  style="margin-left: 120px;">
    <center> 
    <a href="index.php?page=orders&action=create"> <img src="img/food.png" ></a>
    <a href="index.php?page=settings&subpage=products"> <img src="img/product.png" ></a>
    <a href="#"><img src="img/sales.png" ></a> </center>
</div>  
<div class="background"> </div>

</body>
</html>